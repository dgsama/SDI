/**
 * ESTO ES UN OBJETO CON VARIABLES Y FUNCIONES A LAS QUE LLAMAREMOS CUANDO LO
 * NECESITEMOS
 */
module.exports = {
	mongo : null,
	app : null,
	init : function(app, mongo) {
		this.mongo = mongo;
		this.app = app;
	},
    // LA FUNCION NO DEVUELVE TODAS LAS CANCIONES SI NO LAS CANCIONES CORRESPONDIENTES
    // A UNA PAGINA CONCRETA (4 canciones por pag). OBTENEMOS LAS CANCIONES, LAS
    // CONTAMOS; SELECCIONAMOS LAS COLOCADAS EN CIERTAS POSICIONES (SKIP())
    // LIMITANDO A 4 (limit())
    // A LA FUNCION DE CALLBACK LE RETORNAMOS:
    //      1. LA LISTA DE CANCIONES QUE DEBERIAN DE IR A LA PAGINA INDICADA COMO PARAM
    //      2. EL NUMERO TOTAL DE CANCIONES
    obtenerCancionesPg : function(criterio,pg,funcionCallback){
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                var collection = db.collection('canciones');
                collection.count(function(err, count){
                    collection.find(criterio).skip( (pg-1)*4 ).limit( 4 )
                        .toArray(function(err, canciones) {
                            if (err) {
                                funcionCallback(null);
                            } else {
                                funcionCallback(canciones, count);
                            }
                            db.close();
                        });
                });
            }
        });
    },

    // FUNCION PARA RETORNAR LA LISTA DE COMPRAS EN FUNCION DE UN CRITERIO
    // ENVIADO EN EL PARAMETRO
    obtenerCompras : function(criterio,funcionCallback){
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                var collection = db.collection('compras');
                collection.find(criterio).toArray(function(err, usuarios) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(usuarios);
                    }
                    db.close();
                });
            }
        });
    },

    // FUNCION PARA RELACIONAR EL EMAIL DEL COMPRADOR CON LA ID DE LA CANCION
    // COMPRADA
    insertarCompra: function(compra, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                var collection = db.collection('compras');
                collection.insert(compra, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result.ops[0]._id);
                    }
                    db.close();
                });
            }
        });
    },

    // METODO PARA ELIMINAR LA CANCION SELECCIONADA
    eliminarCancion : function(criterio, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                var collection = db.collection('canciones');
                collection.remove(criterio, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result);
                    }
                    db.close();
                });
            }
        });
    },
    modificarCancion : function(criterio, cancion, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                var collection = db.collection('canciones');
                collection.update(criterio, {$set: cancion}, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result);
                    }
                    db.close();
                });
            }
        });
    },

    // FUNCION PARA OBTENER LOS USUARIOS CON UN CRITERIO
	// CONFIGURABLE
    obtenerUsuarios : function(criterio,funcionCallback){
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                var collection = db.collection('usuarios');
                collection.find(criterio).toArray(function(err, usuarios) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(usuarios);
                    }
                    db.close();
                });
            }
        });
    },
	// FUNCION PARA INSERTAR USUARIOS DESPUES DE RELLENAR EL FORMULARIO
	// DE REGISTRO
    insertarUsuario : function(usuario, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                var collection = db.collection('usuarios');
                collection.insert(usuario, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result.ops[0]._id);
                    }
                    db.close();
                });
            }
        });
    },
	// FUNCION PARA OBTENER LAS LISTA DE CANCIONES
	obtenerCanciones : function(/*Para listar canciones por
									criterio*/criterio, funcionCallback){
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                var collection = db.collection('canciones');
                // EN EL FIND INCLUIMOS EL CRITERIO DE BUSQUEDA
				// DESPUES HABRIA QUE IR A LA PETICION EN EL
				// ROUTE EN EL QUE QUEREMO QUE SE MUESTRE LA LISTA
                collection.find(criterio).toArray(function(err, canciones) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(canciones);
                    }
                    db.close();
                });
            }
        });
    },
	insertarCancion : function(cancion, funcionCallback) {
		this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
			if (err) {
				funcionCallback(null);
			} else {
				var collection = db.collection('canciones');
				collection.insert(cancion, function(err, result) {
					if (err) {
						funcionCallback(null);
					} else {
						funcionCallback(result.ops[0]._id);
					}
					db.close();
				});
			}
		});
	}
};
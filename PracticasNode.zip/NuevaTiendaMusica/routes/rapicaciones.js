// VAMOS A IMPLEMENTAR UN API REST
module.exports = function(app, gestorBD) {

    // RETORNA UNA LISTA CON TODAL LAS CANCIONES
    app.get("/api/cancion", function(req, res) {
        gestorBD.obtenerCanciones( {} , function(canciones) {
            if (canciones == null) {
                res.status(500);
                res.json({
                    error : "se ha producido un error"
                })
            } else {
                // CODIGO DE RESPUESTA
                res.status(200);
                // RESPUESTA EN FORMATO JSON
                res.send( JSON.stringify(canciones) );
            }
        });
    });

    // RETORNA LA CANCION CON ID id
    app.get("/api/cancion/:id", function(req, res) {
        var criterio = { "_id" : gestorBD.mongo.ObjectID(req.params.id)}

        gestorBD.obtenerCanciones(criterio,function(canciones){
            if ( canciones == null ){
                res.status(500);
                res.json({
                    error : "se ha producido un error"
                })
            } else {
                res.status(200);
                res.send( JSON.stringify(canciones[0]) );
            }
        });
    });

    // UTILIZA EL METODO HTTP DELETE; LA PETICION SERA DEL ESTILO DELETE
    app.delete("/api/cancion/:id", function(req, res) {
        var criterio = { "_id" : gestorBD.mongo.ObjectID(req.params.id)}

        gestorBD.eliminarCancion(criterio,function(canciones){
            if ( canciones == null ){
                res.status(500);
                res.json({
                    error : "se ha producido un error"
                })
            } else {
                res.status(200);
                res.send( JSON.stringify(canciones) );
            }
        });
    });

    // PARA AGREGAR UN RECURSO CANCION. LA RESPUESTA A LA PETICION INCLUIRA
    // EL CODIGO DE HTTP 201 - CREATED, ADEMAS DE UN MENSAJE EN JSON
    app.post("/api/cancion", function(req, res) {
        var cancion = {
            nombre : req.body.nombre,
            genero : req.body.genero,
            precio : req.body.precio,
        }
        // ¿Validar nombre, genero, precio?

        gestorBD.insertarCancion(cancion, function(id){
            if (id == null) {
                res.status(500);
                res.json({
                    error : "se ha producido un error"
                })
            } else {
                res.status(201);
                res.json({
                    mensaje : "canción insertarda",
                    _id : id
                })
            }
        });
    });

    // ESTA FUNCION DE MODIFICAR SERA MUY SIMILAR A LA DE CREAR, UTILIZAREMOS
    // EL METODO PUT. EN LA URL DEBE APARECER EL ID DE LA CANCION A
    // MODIFICAR. EN EL CUERPO DE LA PETICION SE ENVIARAN LOS DATOS QUE
    // SE DESEEN MODIFICAR
    app.put("/api/cancion/:id", function(req, res) {

        var criterio = { "_id" : gestorBD.mongo.ObjectID(req.params.id) };

        var cancion = {}; // Solo los atributos a modificar
        if ( req.body.nombre != null)
            cancion.nombre = req.body.nombre;
        if ( req.body.genero != null)
            cancion.genero = req.body.genero;
        if ( req.body.precio != null)
            cancion.precio = req.body.precio;
        gestorBD.modificarCancion(criterio, cancion, function(result) {
            if (result == null) {
                res.status(500);
                res.json({
                    error : "se ha producido un error"
                })
            } else {
                res.status(200);
                res.json({
                    mensaje : "canción modificada",
                    _id : id
                })
            }
        });
    });

    // IMPLEMENTACION DE TOKEN POR LOGIN. CREAMOS UN SERVICIO PARA
    // IDENTIFICAR AL USUARIO ASOCIADO A LA URL, MUY SIMILAR AL LOGIN YA
    // IMPLEADO. A PARTIR DEL EMAIL Y LA PASS SE REALIZA UNA BUSQUEDA EN LA
    // BASE, SI HAY COINCIDENCIA RETORNAMOS UN JSON CON EL PARAMETRO
    // AUTENTICADO A TRUE, SI NO LA HAY RETORNAMOS UN FALSE
    app.post("/api/autenticar/", function(req, res) {
        var seguro = app.get("crypto").createHmac('sha256', app.get('clave'))
            .update(req.body.password).digest('hex');
        var criterio = {
            email : req.body.email,
            password : seguro
        }

        gestorBD.obtenerUsuarios(criterio, function(usuarios) {
            if (usuarios == null || usuarios.length == 0) {
                res.status(401); // Unauthorized
                res.json({
                    autenticado : false
                })
            } else {
                // CUANDO LOS CREDENCIALES SEAN CORRECTOS GENERAMOS UN
                // TOKEN ALMACENANDO EN EL, EL EMAIL DEL USUARIO Y EL
                // TIEMPO. RETORNAMOS EL TOKEN COMO RESPUESTA
                var token = app.get('jwt').sign(
                    {usuario: criterio.email , tiempo: Date.now()/1000},
                    "secreto");
                res.status(200);
                res.json({
                    autenticado: true,
                    token : token
                });
            }

        });
    });

}
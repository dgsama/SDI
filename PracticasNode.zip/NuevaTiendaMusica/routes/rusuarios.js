/**
 * Funcionan como los UsersController de spring, responden a las peticiones
 */
module.exports = function(app, swig, gestorBD) {
	app.get("/usuarios", function(req, res) {
		res.send("ver usuarios");
	});

    app.get("/registrarse", function(req, res) {
        var respuesta = swig.renderFile('views/bregistro.html', {});
        res.send(respuesta);
    });

    // POST DEL REGISTRO
    app.post('/usuario', function(req, res) {
        var seguro = app.get("crypto").createHmac('sha256', app.get('clave'))
            .update(req.body.password).digest('hex');
        var usuario = {
            email : req.body.email,
            password : seguro
        }
        // AÑADIMOS AL USUARIO EN LA BASE
        gestorBD.insertarUsuario(usuario, function(id) {
            if (id == null){
                // LANZAMOS EL MENSAJE DE ERROR
                res.redirect("/registrarse?mensaje=Error al registrar usuario")
            } else {
                // LANZAMOS MENSAJE DE USUARIO REGISTRADO
                res.redirect("/identificarse?mensaje=Nuevo usuario registrado");

            }
        });
    });

    // OBTENDREMOS DEL POST LOS DATOS DEL USUARIO Y REALIZARA
	// UNA BUSQUEDA A TRAVES DEL GESTORBG.obtenerUsuarios
	// SI RETORNA COINCIDENCIAS ES QUE EL USUARIO EXISTE.
	// RECORDAR QUE PARA QUE LA BUSQUEDA FUNCIONE EL PASSWORD
	// DEBEESTAR ENCRIPTADO CON EL MISMO SISTEMA QUE CUANDO SE
	// SE GUARDARON LOS DATOS
    app.post("/identificarse", function(req, res) {
        var seguro = app.get("crypto").createHmac('sha256', app.get('clave'))
            .update(req.body.password).digest('hex');
        var criterio = {
            email : req.body.email,
            password : seguro
        }
        gestorBD.obtenerUsuarios(criterio, function(usuarios) {
            if (usuarios == null || usuarios.length == 0) {
                // PODEMOS ACCEDER A LA SESION CON REQ.SESSION
                req.session.usuario = null;
                // ENVIAMOS EL MENSAJE A LA PLANTILLA PARA MOSTRAR EL ERROR DE
                // DATOS INCORRECTOS
                res.redirect("/identificarse" +
                    "?mensaje=Email o password incorrecto"+
                    "&tipoMensaje=alert-danger ");
            } else {
                req.session.usuario = usuarios[0].email;
                // UNA VEZ IDENTIFICADO LE REDIRECCIONO A PUBLICACIONES
                res.redirect("/publicaciones");
            }
        });
    });

    app.get('/desconectarse', function (req, res) {
        req.session.usuario = null;
        res.send("Usuario desconectado");
    })





};

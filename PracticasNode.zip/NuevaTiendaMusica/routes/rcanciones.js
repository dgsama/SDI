/**
 * Funcionan como los CancionController de spring, responden a las peticiones
 * que lleguen
 */
module.exports = function(app, swig, gestorBD) {

	app.get('/canciones/agregar', function(req, res) {
        if ( req.session.usuario == null){
            res.redirect("/tienda");
            return;
        }
		var respuesta = swig.renderFile('views/bagregar.html', {

		});
		res.send(respuesta);
	})

	app.get("/canciones", function(req, res) {
		// Con req.query.nombre(cadenas de texto) recogemos el parametro
		// enviado en la URL con el nombre nombre. Al ser opcinales
		// saldra undefined si el valor no llega, podemos comprobar antes
		// si hay valor si es distinto de null o si el typeOf() es
		// distinto de undefined
		/*
		 * var respuesta = ""; if (req.query.nombre != null) respuesta +=
		 * 'Nombre: ' + req.query.nombre + '<br>'; if (typeof
		 * (req.query.autor) != "undefined") respuesta += 'Autor: ' +
		 * req.query.autor; res.send(respuesta); res.send("Ver canciones");
		 */
		var canciones = [ {
			"nombre" : "Blank space",
			"precio" : "1.2"
		}, {
			"nombre" : "See you again",
			"precio" : "1.3"
		}, {
			"nombre" : "Uptown Funk",
			"precio" : "1.1"
		} ];

		// la funcion renderFile recibe como parametros la plantilla
		// y los parametros que queremos enviar a la esta, el retorno
		// será el html generado por la plantilla el cual podemos enviar
		// como respuesta.
		var respuesta = swig.renderFile('views/btienda.html', {
			vendedor : 'Tienda de canciones',
			canciones : canciones
		});

		res.send(respuesta);
	});

	app.get('/suma', function(req, res) {
		var respuesta = parseInt(req.query.num1) + parseInt(req.query.num2);
		res.send(String(respuesta));
	})

	// tambien se pueden embeber los parametros en la URL
	// http://localhost:8081/canciones/121/ para eso en la respuesta
	// añadimos : en el parametro a recibir, en este caso :id
	app.get('/canciones/:id', function(req, res) {
		var respuesta = 'id: ' + req.params.id;
		res.send(respuesta);
	})

	app.get('/canciones/:genero/:id', function(req, res) {
		var respuesta = 'id: ' + req.params.id + '<br>' + 'Genero: '
				+ req.params.genero;
		res.send(respuesta);
	})

	app.post("/cancion", function(req, res) {
		// COMPRUEBA SI HAY UN USUARIO EN SESION, SI NO LO REDIRIGE A
		// /TIENDA
        if ( req.session.usuario == null){
            res.redirect("/tienda");
            return;
        }
		// CREAMOS UN OBJETO CON LOS PARAMETROS RECIBIDOS
		var cancion = {
			nombre : req.body.nombre,
			genero : req.body.genero,
			precio : req.body.precio,
            autor: req.session.usuario
		}
		// res.send(req.body.nombre);
		// CONECTARSE con EL GESTORBD
		gestorBD.insertarCancion(cancion, function(id) {
			if (id == null) {
				res.send("Error al insertar ");
			} else {
				// HACEMOS LA SUBIDA DE FICHEROS Y DESPUES GUARDAMOS
				if (req.files.portada != null) {
					var imagen = req.files.portada;
					// guardamos las imagenes en public portadas
					imagen.mv('public/portadas/' + id + '.png', function(err) {
						if (err) {
							res.send("Error al subir la portada");
						} else {
							if (req.files.audio != null) {
								 var audio = req.files.audio;

								 audio.mv('public/audios/'+id+'.mp3', function(err) {
								 if (err) {
									 res.send("Error al subir el audio");
								 } else {
									 if(req.files.audio != null){
										 var audio = req.files.audio;
										 audio.mv('public/audios/' + id + '.mp3', function(err){
											 if(err){
												 res.send("Error al subir el audio");
											 }else{
                                                 res.redirect("/publicaciones");
											 }
										 })
										 
									 }
								 }
							});
						}
						}
					});
				}
			}
		});
		
		/*
		 * VERSION USANDO mongo COMO PARAMETRO
		 * mongo.MongoClient.connect(app.get('db'), function(err, db) { if (err) {
		 * res.send("Error de conexión: " + err); } else { var collection =
		 * db.collection('canciones'); collection.insert(cancion, function(err,
		 * result) { if (err) { res.send("Error al insertar " + err); } else {
		 * res.send("Agregada id: " + result.ops[0]._id); } db.close(); }); }
		 * });
		 */
	});

    app.get("/tienda", function(req, res) {
    	//AÑADIMOS EL CRITERIO
		var criterio = {};
		// COGEMOS EL CRITERIO DE LA URL
		if( req.query.busqueda != null ){
			// AÑADIMOS UN EXPRESION REGULAR PARA COMPROBAR LAS CANCIONES
			// QUE CONTENGAN LAS CADENAS EN EN SU NOMBRE
			criterio =
				{ "nombre" : {$regex : ".*"+req.query.busqueda+".*"}};
		}
        var pg = parseInt(req.query.pg); // Es String !!!
        if ( req.query.pg == null){ // Puede no venir el param
            pg = 1;
        }
        gestorBD.obtenerCancionesPg(criterio, pg , function(canciones, total ) {
            if (canciones == null) {
                res.send("Error al listar ");
            } else {

                var pgUltima = total/4;
                if (total % 4 > 0 ){ // Sobran decimales
                    pgUltima = pgUltima+1;
                }

                // A LA VISTA BTIENDA LE ENVIAMOS LA ULTIMA PAGINA PARA MOSTRAR
                // TODAS LAS CANCIONES, LA LISTA DE CANCIONES Y LA PAGINA ACTUAL
                var respuesta = swig.renderFile('views/btienda.html',
                    {
                        canciones : canciones,
                        pgActual : pg,
                        pgUltima : pgUltima
                    });
                res.send(respuesta);
            }
        });
    });

    app.get('/cancion/:id', function (req, res) {
        var criterio = { "_id" : gestorBD.mongo.ObjectID(req.params.id) };

        gestorBD.obtenerCanciones(criterio,function(canciones){
            if ( canciones == null ){
                res.send(respuesta);
            } else {
                // VAMOS A OBTENER EL CAMBIO DE DIVISAS Y MULTIPLICAR
                // EL PRECIO ACTUAL POR EL CAMBIO PARA OBTENER EL PRECIO
                // EN DOLARES, AGREGAMOS UNA NUEVA VARIABLE usd A LA
                // cancion QUE SE ENVIA A LA VISTA bcancion
                // Insertar un anuncio
                var anuncio = {
                    descripcion : 'Nuevo anuncio',
                    precio : '10'
                };
                var configuracion = {
                    url: "http://ejemplo.ejemplo/anuncio",
                    method: "POST",
                    json: true,
                    headers: {
                        "content-type": "application/json",
                    },
                    body: anuncio
                }

                var rest = app.get("rest");
                rest(configuracion, function (error, response, body) {
                    console.log("cod: " + response.statusCode + " Cuerpo :" + body);
                    var objetoRespuesta = JSON.parse(body);
                    var cambioUSD = objetoRespuesta.rates.USD;
                    // nuevo campo "usd"
                    canciones[0].usd = cambioUSD * canciones[0].precio;
                    var respuesta = swig.renderFile('views/bcancion.html',
                        {
                            cancion: canciones[0]
                        });
                    res.send(respuesta);
                    })
                }
        });
    })

	// VER LAS CANCIONES QUE EL USUARIO EN SESION HA PUBLICADO
    app.get("/publicaciones", function(req, res) {
        var criterio = { autor : req.session.usuario };
        gestorBD.obtenerCanciones(criterio, function(canciones) {
            if (canciones == null) {
                res.send("Error al listar ");
            } else {
                var respuesta = swig.renderFile('views/bpublicaciones.html',
                    {
                        canciones : canciones
                    });
                res.send(respuesta);
            }
        });
    });

    // VISTA PARA MODIFICAR LA CANCION CON ID id
    app.get('/cancion/modificar/:id', function (req, res) {
        var criterio = { "_id" : gestorBD.mongo.ObjectID(req.params.id) };
        gestorBD.obtenerCanciones(criterio,function(canciones){
            if ( canciones == null ){
                res.send(respuesta);
            } else {
                var respuesta = swig.renderFile('views/bcancionModificar.html',
                    {
                        cancion : canciones[0]
                    });
                res.redirect("/publicaciones");
            }
        });
    })

	// POST PARA MODIFICAR LA CANCION CON ID ESCOGIDO, HABRIA AHORA
	// QUE INCLUIR EL CODIGO PARA MODIFICAR LA PORTADA Y OTRO PARA EL
	// AUDIO
    app.post('/cancion/modificar/:id', function (req, res) {
        var id = req.params.id;
        var criterio = { "_id" : gestorBD.mongo.ObjectID(id) };
        var cancion = {
            nombre : req.body.nombre,
            genero : req.body.genero,
            precio : req.body.precio
        }
        gestorBD.modificarCancion(criterio, cancion, function(result) {
            if (result == null) {
                res.send("Error al modificar ");
            } else {
                paso1ModificarPortada(req.files, id , function (result) {
                    if( result == null){
                        res.send("Error en la modificación");
                    } else {
                        res.send("Modificado");
                    }
                });
            }
        });
    })

	// FUNCION PARA CAMBIAR LA PORTADA DE LA CANCION
    function paso1ModificarPortada(files, id, callback){
        if (files.portada != null) {
            var imagen =files.portada;
            imagen.mv('public/portadas/' + id + '.png', function(err) {
                if (err) {
                    callback(null); // ERROR
                } else {
                	// SI NO HAY ERROR SE PASA A MODIFICAR AUDIO
                    paso2ModificarAudio(files, id, callback); // SIGUIENTE
                }
            });
        } else {
        	// SI NO HAY PORTADA QUE MODIFICAR SE PASA AL AUDIO
            paso2ModificarAudio(files, id, callback); // SIGUIENTE
        }
    }

    function paso2ModificarAudio(files, id, callback){
        if (files.audio != null) {
            var audio = files.audio;
            audio.mv('public/audios/'+id+'.mp3', function(err) {
                if (err) {
                    callback(null); // ERROR
                } else {
                    callback(true); // FIN
                }
            });
        } else {
            callback(true); // FIN
        }
    }

    // VISTA PARA ELIMIAR CANCION CON ID id, PARA LLAMARLA LLAMAMOS AL
	// METODO eliminarCancion DEL GESTORBD
    app.get('/cancion/eliminar/:id', function (req, res) {
        var criterio = { "_id" : gestorBD.mongo.ObjectID(req.params.id) };
        gestorBD.eliminarCancion(criterio,function(canciones){
            if ( canciones == null ){
                res.send(respuesta);
            } else {
                res.redirect("/publicaciones");
            }
        });
    })

    // RESPUESTA PARA COMPRAR UNA CANCION, UNA VEZ AGREGADA LA COMPRA LE REDIRIGIMOS
    // A /COMPRAS
    app.get('/cancion/comprar/:id', function (req, res) {
        var cancionId = gestorBD.mongo.ObjectID(req.params.id);
        var compra = {
            usuario : req.session.usuario,
            cancionId : cancionId
        }
        gestorBD.insertarCompra(compra ,function(idCompra){
            if ( idCompra == null ){
                res.send(respuesta);
            } else {
                res.redirect("/compras");
            }
        });
    })

    // 1. OBTENEMOS LAS COMPRAS REALIZADAS POR EL USUARIO EN SESION. CON EL ID DE CADA
    // UNA OBTENDREMOS EL RESTO DE INFORMACION
    // 2. LAS GUARDAMOS EN UN ARRRAY
    // 3. LAS MOSTRAMOS EN LA VISTA BCOMPRAS
    app.get('/compras', function (req, res) {
        var criterio = { "usuario" : req.session.usuario };
        gestorBD.obtenerCompras(criterio ,function(compras){
            if (compras == null) {
                res.send("Error al listar ");
            } else {
                var cancionesCompradasIds = [];
                for(i=0; i < compras.length; i++){
                    cancionesCompradasIds.push( compras[i].cancionId );
                }
                var criterio = { "_id" : { $in: cancionesCompradasIds } }
                gestorBD.obtenerCanciones(criterio ,function(canciones){
                    var respuesta = swig.renderFile('views/bcompras.html',
                        {
                            canciones : canciones
                        });
                    res.send(respuesta);
                });
            }
        });
    })
};